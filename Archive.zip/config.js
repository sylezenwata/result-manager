require('dotenv').config();

let _config = {};

_config.port = process.env.PORT

module.exports = _config;